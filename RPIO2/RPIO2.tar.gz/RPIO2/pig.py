import time
import pigpio

pi = pigpio.pi()
pi.wave_clear()

GP = 17
pi.set_mode(GP, pigpio.OUTPUT)


wf = []

wf.append(pigpio.pulse(1<<GP,  0    ,  0 ))
wf.append(pigpio.pulse(0    ,  1<<GP,  10 ))

wf.append(pigpio.pulse(1<<GP,  0    ,  15 ))
wf.append(pigpio.pulse(0    ,  1<<GP,  75 ))

e = pi.wave_add_generic(wf)

wid = pi.wave_create()
e = pi.wave_send_repeat(wid)

print(  "wave_get_cbs    ",  pi.wave_get_cbs()       )
print(  "wave_get_max_cbs",  pi.wave_get_max_cbs()   )
print(  "wave_get_micros ",  pi.wave_get_micros()    )

time.sleep(20)

pi.stop()