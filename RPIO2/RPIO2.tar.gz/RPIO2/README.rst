RPIO2 is an advanced GPIO module for the Raspberry Pi.

* PWM via DMA (up to 1us resolution)
* Well documented, fast source code with minimal CPU usage
* Open source (LGPLv3+)


`Visit pythonhosted.org/RPIO for the documentation. <http://pythonhosted.org/RPIO>`_


Installation
------------

The easiest way to install/update RPIO on a Raspberry Pi is with either ``easy_install`` or ``pip``::

    $ sudo python setup.py install

After the installation you can use ``iimport RPIO2.PWM as PWM`` .


Examples
--------

You can find lots of examples in the `/examples/ source directory_.


Feedback
--------

Please send feedback and ideas to chris@linuxuser.at, and `open an issue at Github <https://github.com/metachris/RPIO/issues/new>`_
if you've encountered a bug.


License
-------

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details at
    <http://www.gnu.org/licenses/lgpl-3.0-standalone.html>


Special Thanks
--------------

    `csegit <https://github.com/csegit>`_, `waveform80 <https://github.com/waveform80>`_,
    `nils-werner <https://github.com/nils-werner>`_, `friedcell <https://github.com/friedcell>`_,
    `zejn <https://github.com/zejn>`_, `dbeal <https://github.com/dbeal>`_,
    `paul-1 <https://github.com/paul-1>`_


Copyright
---------

    Copyright (C) 2015 Gerhard Hepp <heppg@web.de>


Links
-----

* http://pythonhosted.org/RPIO
* http://pypi.python.org/pypi/RPIO
* http://pypi.python.org/pypi/RPi.GPIO
* http://www.raspberrypi.org/wp-content/uploads/2012/02/BCM2835-ARM-Peripherals.pdf
* http://www.kernel.org/doc/Documentation/gpio.txt
* `semver versioning standard <http://semver.org/>`_


Changes
-------

Please refer to the `'Changes' section in the documentation _.
