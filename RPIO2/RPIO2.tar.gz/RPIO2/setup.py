import os
from setuptools import setup, Extension


def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


setup(
    name="RPIO2",
    version="0.11.2",
    package_dir={"": "source"},
    packages=['RPIO2', 'RPIO2.PWM'],
    ext_modules=[
            Extension('RPIO2._GPIO', 
                      ['source/c_gpio/py_gpio.c',
                       'source/c_gpio/c_gpio.c', 
                       'source/c_gpio/cpuinfo.c'],
                extra_compile_args=["-std=gnu99", "-Wno-error=declaration-after-statement"]),
            
            Extension('RPIO2.PWM._PWM', 
                      ['source/c_pwm/pwm.c',
                       'source/c_pwm/pwm_py.c',
                       'source/c_pwm/mailbox.c'],
                extra_compile_args=["-std=gnu99", "-Wno-error=declaration-after-statement"])],
      
    scripts=["source/scripts/rpio", "source/scripts/rpio-curses"],

    description=(("Advanced GPIO for the Raspberry Pi, Pi2. Extends RPi.GPIO with "
            "PWM, GPIO interrups, TCP socket interrupts, command line tools "
            "and more")),
    long_description=read('README.rst'),
    url="https://github.com/metachris/RPIO",

    author="G. Hepp, based on work from Chris Hager and others",
    author_email="heppg@web.de",

    license="LGPLv3+",
    keywords=["raspberry", "raspberry pi", "interrupts", "gpio", "rpio", "dma"],
    classifiers=[
        "Development Status :: 5 - Beta",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Operating System :: POSIX :: Linux",
        "Topic :: Utilities",
        "Topic :: Software Development",
        "Topic :: Home Automation",
        "Topic :: System :: Hardware",
        "Intended Audience :: Developers",
        ("License :: OSI Approved :: "
                "GNU Lesser General Public License v3 or later (LGPLv3+)"),
        "License :: Other/Proprietary License",
    ],
)
