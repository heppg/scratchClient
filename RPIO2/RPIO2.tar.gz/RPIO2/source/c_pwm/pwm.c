/*
 * This file is part of RPIO.
 *
 * Copyright
 *
 *     Copyright (C) 2013 Chris Hager <chris@linuxuser.at>
 *     Extensions 2015, 2016 by Gerhard Hepp
 *
 * License
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU Lesser General Public License as published
 *     by the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU Lesser General Public License for more details at
 *     <http://www.gnu.org/licenses/lgpl-3.0-standalone.html>
 *
 * Documentation
 *
 *     http://pythonhosted.org/RPIO
 *
 *
 * pwm.c, based on the excellent servod.c by Richard Hirst, provides flexible
 * PWM via DMA for the Raspberry Pi, supporting a resolution of up to 1us,
 * all 15 DMA channels, multiple GPIOs per channel, timing by PWM (default)
 * or PCM, a Python wrapper, and more.
 *
 * Feedback is much appreciated.
 *
 *
 * SUBCYCLES
 * ---------
 * One second is divided into subcycles of user-defined length (within 2ms and 1s)
 * which will be repeated endlessly. The subcycle length is set
 * per DMA channel; the shorter the length of a subcycle, the less DMA memory will
 * be used. Do not set below 2ms - we started seeing weird behaviors of the RPi.
 *
 * To use servos for instance, a typical subcycle time is 20ms (which will be repeated
 * 50 times a second). Each subcycle includes the specific pulse(s) to set the servo
 * to the correct position.
 *
 * You can add pulses to the subcycle, and they will be repeated accordingly (eg.
 * a 100ms subcycle will be repeated 10 times per second; as are all the pulses
 * within that subcycle). You can use any number of GPIOs, and set multiple pulses
 * for each one. Longer subcycles use more DMA memory.
 *
 *
 * PULSE WIDTH INCREMENT GRANULARITY
 * ---------------------------------
 * Another very important setting is the pulse width increment granularity, which
 * defaults to 10µs and is used for _all_ DMA channels (since its passed to the PWM
 * timing hardware). Under the hood you need to set the pulse widths as multiples
 * of the increment-granularity. Eg. in order to set 500µs pulses with a granularity
 * setting of 10µs, you'll need to set the pulse-width as 50 (50 * 10µs = 500µs).
 * Less granularity needs more DMA memory.
 *
 * To achieve shorter pulses than 10µs, you simply need set a lower granularity.
 *
 *
 * WARNING
 * -------
 * pwm.c is in beta and currently not yet fully tested. Setting very long or very short
 * subcycle times may cause unreliable signals. Please send feedback to chris@linuxuser.at.
 *
 *
 * TODO
 * ----
 * - add_pulse: check exact start/stop timeslot to avoid set0/clr0 collisions
 */

// #define DEBUG
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include "pwm.h"

#include "mailbox.h"

// 15 DMA channels are usable on the RPi (0..14)
#define DMA_CHANNELS    15

// Standard page sizes
#define PAGE_SIZE       4096
#define PAGE_SHIFT      12

#define BCM_PASSWD 0x5A000000

// Memory Addresses
// #define DMA_BASE        0x20007000
#define DMA_CHANNEL_INC 0x100
#define DMA_LEN         0x24
// #define PWM_BASE        0x2020C000
#define PWM_LEN         0x28
// #define CLK_BASE        0x20101000
#define CLK_LEN         0xA8
// #define GPIO_BASE       0x20200000
#define GPIO_LEN        0x100
//#define PCM_BASE        0x20203000
#define PCM_LEN         0x24

int board_model = 0;

#define DMA_BASE_OFFSET		0x00007000
#define PWM_BASE_OFFSET		0x0020C000
#define CLK_BASE_OFFSET	    0x00101000
#define GPIO_BASE_OFFSET	0x00200000
#define PCM_BASE_OFFSET		0x00203000

#define DMA_VIRT_BASE		(periph_virt_base + DMA_BASE_OFFSET)
#define PWM_VIRT_BASE		(periph_virt_base + PWM_BASE_OFFSET)
#define CLK_VIRT_BASE		(periph_virt_base + CLK_BASE_OFFSET)
#define GPIO_VIRT_BASE		(periph_virt_base + GPIO_BASE_OFFSET)
#define PCM_VIRT_BASE		(periph_virt_base + PCM_BASE_OFFSET)

#define PWM_PHYS_BASE		(periph_phys_base + PWM_BASE_OFFSET)
#define PCM_PHYS_BASE		(periph_phys_base + PCM_BASE_OFFSET)
#define GPIO_PHYS_BASE		(periph_phys_base + GPIO_BASE_OFFSET)

// Datasheet p. 51:
#define DMA_NO_WIDE_BURSTS  (1<<26)
#define DMA_WAIT_RESP   (1<<3)
#define DMA_D_DREQ      (1<<6)
#define DMA_PER_MAP(x)  ((x)<<16)
#define DMA_END         (1<<1)
#define DMA_RESET       (1<<31)
#define DMA_INT         (1<<2)

// Each DMA channel has 3 writeable registers:
#define DMA_CS          (0x00/4)
#define DMA_CONBLK_AD   (0x04/4)
#define DMA_DEBUG       (0x20/4)

// GPIO Memory Addresses
#define GPIO_FSEL0      (0x00/4)
#define GPIO_SET0       (0x1c/4)
#define GPIO_CLR0       (0x28/4)
#define GPIO_LEV0       (0x34/4)
#define GPIO_PULLEN     (0x94/4)
#define GPIO_PULLCLK    (0x98/4)

// GPIO Modes (IN=0, OUT=1)
#define GPIO_MODE_IN    0
#define GPIO_MODE_OUT   1

// PWM Memory Addresses

#define PWM_CTL         (0x00/4)
#define PWM_STA      1
#define PWM_DMAC        (0x08/4)
#define PWM_RNG1        (0x10/4)
#define PWM_FIFO        (0x18/4)

#define PWMCLK_CNTL     40
#define PWMCLK_DIV      41

#define CLK_CNTL_BUSY    (1 <<7)
#define CLK_CNTL_KILL    (1 <<5)
#define CLK_CNTL_ENAB    (1 <<4)
#define CLK_CNTL_SRC_PLLD 6

#define PWMCTL_PWEN1    (1<<0)
#define PWMCTL_MODE1    (1<<1)
#define PWMCTL_CLRF     (1<<6)
#define PWMCTL_USEF1    (1<<5)

#define PWMDMAC_ENAB    (1<<31)
#define PWMDMAC_THRSHLD ((15<<8) | (15<<0))

#define PCM_CS_A        (0x00/4)
#define PCM_FIFO_A      (0x04/4)
#define PCM_MODE_A      (0x08/4)
#define PCM_RXC_A       (0x0c/4)
#define PCM_TXC_A       (0x10/4)
#define PCM_DREQ_A      (0x14/4)
#define PCM_INTEN_A     (0x18/4)
#define PCM_INT_STC_A   (0x1c/4)
#define PCM_GRAY        (0x20/4)

#define PCMCLK_CNTL     38
#define PCMCLK_DIV      39

static uint32_t periph_phys_base;
static uint32_t periph_virt_base;
static uint32_t dram_phys_base;
static uint32_t mem_flag;

#define BUS_TO_PHYS(x) ((x)&~0xC0000000)

struct Mbox {
	int handle; /* From mbox_open() */
	unsigned mem_ref; /* From mem_alloc() */
	unsigned bus_addr; /* From mem_lock() */
	uint8_t *virt_addr; /* From mapmem() */
	uint32_t size; /* Required size */
};

// DMA Control Block Data Structure (p40): 8 words (256 bits)
typedef struct {
	uint32_t info;   // TI: transfer information
	uint32_t src;    // SOURCE_AD
	uint32_t dst;    // DEST_AD
	uint32_t length; // TXFR_LEN: transfer length
	uint32_t stride; // 2D stride mode
	uint32_t next;   // NEXTCONBK
	uint32_t pad[2]; // _reserved_
} dma_cb_t;

// Memory mapping
typedef struct {
	uint8_t *virtaddr;
	uint32_t physaddr;
} page_map_t;
//
// Main control structure per channel
//
struct channel {
	// uint8_t *virtbase;
	//uint32_t *sample;
	//dma_cb_t *cb;
	//page_map_t *page_map;
	volatile uint32_t *dma_reg;

	// Set by user
	uint32_t subcycle_time_us;

	// Set by system
	uint32_t num_samples;
	uint32_t num_cbs;
	uint32_t num_pages;

	// Used only for control purposes
	uint32_t width_max;

	struct Mbox mbox;

	uint8_t initialized;
	// max size of pwm so far

	uint32_t pwm_width[32];
};

//
// One control structure per channel
// it is usually not needed to have multiple channels.
//
static struct channel channels[DMA_CHANNELS];

// Pulse width increment granularity
static uint16_t pulse_width_incr_us = -1;
static uint8_t _is_setup = 0;
static int gpio_setup = 0; // bitfield for setup gpios (setup = out/low)

// Common registers
static volatile uint32_t *pwm_reg;
static volatile uint32_t *pcm_reg;
static volatile uint32_t *clk_reg;
static volatile uint32_t *gpio_reg;

// Defaults
static int delay_hw = DELAY_VIA_PWM;
static int log_level = LOG_LEVEL_DEFAULT;

// if set to 1, calls to fatal will not exit the program or shutdown DMA/PWM, but just sets
// the error_message and returns an error code. soft_fatal is enabled by default by the 
// python wrapper, in order to convert calls to fatal(..) to exceptions.
static int soft_fatal = 0;

// cache for a error message
static char error_message[256];

// --------------------------------------------------------------------------------------
// Debug logging
void set_loglevel(int level) {
	log_level = level;
}

static void log_debug(char* fmt, ...) {

	if (log_level > LOG_LEVEL_DEBUG)
		return;

	va_list args;
	va_start(args, fmt);
	vprintf(fmt, args);
	va_end(args);
}

// --------------------------------------------------------------------------------------
// Sets a GPIO to either GPIO_MODE_IN(=0) or GPIO_MODE_OUT(=1)
static void gpio_set_mode(uint32_t pin, uint32_t mode) {
	uint32_t fsel = gpio_reg[GPIO_FSEL0 + pin / 10];

	fsel &= ~(7 << ((pin % 10) * 3));
	fsel |= mode << ((pin % 10) * 3);
	gpio_reg[GPIO_FSEL0 + pin / 10] = fsel;
}

static void gpio_set(int pin, int level) {
	if (level)
		gpio_reg[GPIO_SET0] = 1 << pin;
	else
		gpio_reg[GPIO_CLR0] = 1 << pin;
}

// Set GPIO to OUTPUT, Low
static void init_gpio(int gpio) {
	log_debug("init_gpio %d\n", gpio);

	gpio_set(gpio, 0);
	gpio_set_mode(gpio, GPIO_MODE_OUT);

	gpio_setup |= 1 << gpio;
}

static void init_gpio_high(int gpio) {
	log_debug("init_gpio_high %d\n", gpio);

	gpio_set(gpio, 1);
	gpio_set_mode(gpio, GPIO_MODE_OUT);

	gpio_setup |= 1 << gpio;
}

// --------------------------------------------------------------------------------------
// Very short delay as demanded per datasheet
static void udelay(int us) {
	struct timespec ts = { 0, us * 1000 };

	nanosleep(&ts, NULL);
}

// --------------------------------------------------------------------------------------
// Shutdown -- its important to reset the DMA before quitting
void shutdown(void) {
	log_debug("shutdown()\n");

	int i;

	for (i = 0; i < DMA_CHANNELS; i++) {
		if (is_channel_initialized(i)) {
			log_debug("shutting down dma channel %d\n", i);
			clear_channel(i);
			udelay(channels[i].subcycle_time_us);
			channels[i].dma_reg[DMA_CS] = DMA_RESET;
			udelay(10);
		}
	}
	for (i = 0; i < DMA_CHANNELS; i++) {
		if (is_channel_initialized(i)) {
			if (channels[i].mbox.virt_addr != NULL) {

				unmapmem(channels[i].mbox.virt_addr, channels[i].mbox.size);
				mem_unlock(channels[i].mbox.handle, channels[i].mbox.mem_ref);
				mem_free(channels[i].mbox.handle, channels[i].mbox.mem_ref);
			}
		}
	}
}

// --------------------------------------------------------------------------------------
// Terminate is triggered by signals
static void terminate(void) {
	log_debug("terminate()\n");
	shutdown();
	if (soft_fatal) {
		return;
	}
	exit(EXIT_SUCCESS);
}

// --------------------------------------------------------------------------------------
// Shutdown with an error message. Returns EXIT_FAILURE for convenience.
// if soft_fatal is set to 1, a call to `fatal(..)` will not shut down
// PWM/DMA activity (used in the Python wrapper).
static int fatal(char *fmt, ...) {
	va_list ap;

	// Handle error
	va_start(ap, fmt);
	if (soft_fatal) {
		vsprintf(error_message, fmt, ap);
		return EXIT_FAILURE;
	}
	vfprintf(stderr, fmt, ap);
	va_end(ap);

	// Shutdown all DMA and PWM activity
	shutdown();
	exit(EXIT_FAILURE);
}

// --------------------------------------------------------------------------------------
// Catch all signals possible - it is vital we kill the DMA engine
// on process exit!
static void setup_sighandlers(void) {

	int i;
	for (i = 1; i < 32; i++) {
		// whitelist non-terminating signals
		if (i == SIGCHLD || i == SIGCONT || i == SIGTSTP || i == SIGTTIN || i == SIGTTOU || i == SIGURG || i == SIGWINCH || i == SIGPIPE || // Python handles this
				i == SIGINT || // Python handles this
				i == SIGIO) {
			continue;
		}
		struct sigaction sa;
		memset(&sa, 0, sizeof(sa));
		sa.sa_handler = (void *) terminate;
		sigaction(i, &sa, NULL);
	}
}

// --------------------------------------------------------------------------------------
// Memory mapping
static uint32_t mem_virt_to_phys(int channel, void *virt) {
#if 0
	if (0) {
		uint32_t offset = (uint8_t *) virt - channels[channel].virtbase;
		return channels[channel].page_map[offset >> PAGE_SHIFT].physaddr + (offset % PAGE_SIZE);
	} else
#endif
	{
		uint32_t offset = (uint8_t *) virt - channels[channel].mbox.virt_addr;
		return channels[channel].mbox.bus_addr + offset;
	}
}
// --------------------------------------------------------------------------------------
// Peripherals memory mapping
static void *
map_peripheral(uint32_t base, uint32_t len) {
	int fd = open("/dev/mem", O_RDWR | O_SYNC);
	void * vaddr;

	if (fd < 0)
		fatal("servod: Failed to open /dev/mem: %m\n");
	vaddr = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, base);
	if (vaddr == MAP_FAILED)
		fatal("servod: Failed to map peripheral at 0x%08x: %m\n", base);
	close(fd);

	return vaddr;
}

// --------------------------------------------------------------------------------------
// Returns a pointer to the control block of this channel in DMA memory
uint8_t*
get_cb(int channel) {
#if 0
	if (0) {
		return channels[channel].virtbase + (sizeof(uint32_t) * channels[channel].num_samples);
	} else
#endif
	{
		return channels[channel].mbox.virt_addr + (sizeof(uint32_t) * channels[channel].num_samples);
	}
}

uint8_t*
get_dp(int channel) {
#if 0
	if (0) {
		return channels[channel].virtbase;
	} else
#endif
	{
		return channels[channel].mbox.virt_addr;
	}
}

// --------------------------------------------------------------------------------------
// Reset this channel to original state (all samples=0, all cbs=clr0)
int clear_channel(int channel) {

	uint32_t phys_gpclr0 = periph_phys_base + GPIO_BASE_OFFSET + 0x28;

	dma_cb_t *cbp = (dma_cb_t *) get_cb(channel);
	uint32_t *dp = (uint32_t *) get_dp(channel);

	log_debug("clear_channel: channel=%d\n", channel);
	if (!is_channel_initialized(channel))
		return fatal("Error: channel %d has not been initialized with 'init_channel(..)'\n", channel);

	// First we have to stop all currently enabled pulses
	int i;
	for (i = 0; i < channels[channel].num_samples; i++) {
		cbp->dst = phys_gpclr0;
		cbp += 2;
	}

	// Let DMA do one cycle to actually clear them
	udelay(channels[channel].subcycle_time_us);

	// Finally set all samples to 0 (instead of gpio_mask)
	for (i = 0; i < channels[channel].num_samples; i++) {
		*(dp + i) = 0;
	}

	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
// Clears all pulses for a specific gpio on this channel. Also sets the GPIO to Low.
int clear_channel_gpio(int channel, int gpio) {
	uint32_t *dp = (uint32_t *) get_dp(channel);
	log_debug("clear_channel_gpio: channel=%d, gpio=%d\n", channel, gpio);
	if (!is_channel_initialized(channel))
		return fatal("Error: channel %d has not been initialized with 'init_channel(..)'\n", channel);
	if ((gpio_setup & 1 << gpio) == 0)
		return fatal("Error: cannot clear gpio %d; not yet been set up\n", gpio);

	// Remove this gpio from all samples:
	int i;
	for (i = 0; i < channels[channel].num_samples; i++) {
		*(dp + i) &= ~(1 << gpio);  // set just this gpio's bit to 0
	}

	// Let DMA do one cycle before setting GPIO to low.
	//udelay(channels[channel].subcycle_time_us);

	gpio_set(gpio, 0);
	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
/*
 * set pwm pulse.
 * Do not mix with impulse pattern.
 * when pulses get shorter, an internal delay is inserted.
 */
#ifdef DEBUG
int tstCount = 0;
#endif

int set_pwm(int channel, int gpio, int width) {
#ifdef DEBUG
	tstCount ++;
	if ( tstCount > 1 )
	printf("set_pwm: multiple calls channel=%d, gpio=%d: %d\n", channel, gpio, tstCount);
#endif

	uint32_t phys_gpclr0 = periph_phys_base + GPIO_BASE_OFFSET + 0x28;
	uint32_t phys_gpset0 = periph_phys_base + GPIO_BASE_OFFSET + 0x1c;

	dma_cb_t *cbp = (dma_cb_t *) get_cb(channel);
	uint32_t *dp = (uint32_t *) get_dp(channel);

	log_debug("set_pwm: channel=%d, gpio=%d, width=%d\n", channel, gpio, width);

	if (!is_channel_initialized(channel))
		return fatal("Error: channel %d has not been initialized with 'init_channel(..)'\n", channel);

	//
	// width_max = num_samples - 1
	//
	if (width > channels[channel].width_max + 1) {
		log_debug("set_pwm  %d >> %d !!\n", width, channels[channel].width_max);
		return fatal("Error: cannot add pulse to channel %d: width exceed max_width of %d\n", channel, channels[channel].width_max);
	}

	if ((gpio_setup & (1 << gpio)) == 0) {
		init_gpio(gpio);
	}
	uint32_t pwm_width_old = channels[channel].pwm_width[gpio];

	if (pwm_width_old == width) {
		log_debug("set_pwm A %d  %d, do nothing\n", pwm_width_old, width);

	} else if ((pwm_width_old > 0) && (width == 0)) {
		log_debug("set_pwm_B %d  %d\n", pwm_width_old, width);

		*(dp + 0) &= ~(1 << gpio);
		// Let DMA do one cycle before setting GPIO to low.
		udelay(channels[channel].subcycle_time_us);

		*(dp + pwm_width_old) &= ~(1 << gpio);
		//
		// although procedure to switch control signals seems reasonable, the pin does not switch off
		// when when step is full scale to zero. For this case, switch gpio low
		//
		gpio_set(gpio, 0);

		channels[channel].pwm_width[gpio] = 0 & 0xffffffff;

	} else if ((pwm_width_old == 0) && (width > 0)) {
		log_debug("set_pwm C %d  %d\n", pwm_width_old, width);

		// Clear GPIO at end
		cbp[width * 2].dst = phys_gpclr0;
		*(dp + width) |= 1 << gpio;

		// Set gpio at beginning
		cbp[0 * 2].dst = phys_gpset0;
		*(dp + 0) |= (1 << gpio);

		channels[channel].pwm_width[gpio] = width & 0xffffffff;

	} else if ((pwm_width_old > 0) && (width > 0)) {
		log_debug("set_pwm_D %d  %d\n", pwm_width_old, width);

		// Clear GPIO at new end point
#if 1
		cbp[width * 2].dst = phys_gpclr0;
		*(dp + width) |= 1 << gpio;

		if (width > pwm_width_old) {
			*(dp + pwm_width_old) &= ~(1 << gpio); // set just this gpio's bit to 0
		}
		if (width < pwm_width_old) {
			// when pulses get shorter, then the previous end mark can't be removed immediately-
			// when DMA machine is actually between width and pwm_width_old, then
			// the pulse is not terminated.
			// a delay cures this problem at the cost of some delay time-
			//
			//printf("delay %d\n", ( pwm_width_old - width + 1) * pulse_width_incr_us);
			udelay((pwm_width_old - width + 1) * pulse_width_incr_us);

			*(dp + pwm_width_old) &= ~(1 << gpio); // set just this gpio's bit to 0
		}
#else
		*(dp + width) |= 1 << gpio;
		*(dp + pwm_width_old) &= ~(1 << gpio); // set just this gpio's bit to 0

#endif
		channels[channel].pwm_width[gpio] = width & 0xffffffff;

	}
#ifdef DEBUG
	tstCount--;
#endif
	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
// Update the channel with another pulse within one full cycle. Its possible to
// add more gpios to the same timeslots (width_start). width_start and width are
// multiplied with pulse_width_incr_us to get the pulse width in microseconds [us].
//
// Be careful: if you try to set one GPIO to high and another one to low at the same
// point in time, only the last added action (eg. set-to-low) will be executed on all pins.
// To create these kinds of inverted signals on two GPIOs, either offset them by 1 step, or
// use multiple DMA channels.

int add_channel_pulse(int channel, int gpio, int width_start, int width) {

	uint32_t phys_gpclr0 = periph_phys_base + GPIO_BASE_OFFSET + 0x28;
	uint32_t phys_gpset0 = periph_phys_base + GPIO_BASE_OFFSET + 0x1c;

	dma_cb_t *cbp = (dma_cb_t *) get_cb(channel);
	uint32_t *dp = (uint32_t *) get_dp(channel);

	log_debug("add_channel_pulse: channel=%d, gpio=%d, start=%d, width=%d\n", channel, gpio, width_start, width);

	if (!is_channel_initialized(channel))
		return fatal("Error: channel %d has not been initialized with 'init_channel(..)'\n", channel);
	if (width_start + width > channels[channel].width_max + 1 || width_start < 0)
		return fatal("Error: cannot add pulse to channel %d: width_start+width exceed max_width of %d\n", channel, channels[channel].width_max);

	if ((gpio_setup & (1 << gpio)) == 0) {
		init_gpio(gpio);
	}
	// enable or disable gpio at this point in the cycle
	*(dp + width_start) |= (1 << gpio);
	cbp[width_start * 2].dst = phys_gpset0;

	// Do nothing for the specified width
	int i;
	for (i = 1; i < width - 1; i++) {
		*(dp + width_start + i) &= ~(1 << gpio); // set just this gpio's bit to 0
	}

	// Clear GPIO at end
	*(dp + width_start + width) |= 1 << gpio;
	cbp[(width_start + width) * 2].dst = phys_gpclr0;

	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
//
// Create a channel's pagemap
//
static int make_pagemap(int channel) {
	log_debug("make_pagemap()\n");

	// int i, fd, memfd, pid;
	// char pagemap_fn[64];

	/* Use the mailbox interface to the VC to ask for physical memory */
	// Use the mailbox interface to request memory from the VideoCore
	// We specifiy (-1) for the handle rather than calling mbox_open()
	// so multiple users can share the resource.
	channels[channel].mbox.handle = -1;
	channels[channel].mbox.size = channels[channel].num_pages * PAGE_SIZE;
	//
	// in original code, the size of block is sizeof(*channels[channel].page_map) and not 4096
	//
	{
		channels[channel].mbox.mem_ref = mem_alloc(channels[channel].mbox.handle, //
				channels[channel].mbox.size, PAGE_SIZE, mem_flag);

		if (channels[channel].mbox.mem_ref < 0) {
			fatal("Failed to alloc memory from VideoCore\n");
		}
		log_debug("mem_ref %u\n", channels[channel].mbox.mem_ref);
	}
	{
		channels[channel].mbox.bus_addr = mem_lock(channels[channel].mbox.handle, channels[channel].mbox.mem_ref);
		if (channels[channel].mbox.bus_addr == ~0) {
			mem_free(channels[channel].mbox.handle, channels[channel].mbox.size);
			fatal("Failed to lock memory\n");
		}
	}

	channels[channel].mbox.virt_addr = mapmem(BUS_TO_PHYS(channels[channel].mbox.bus_addr), channels[channel].mbox.size);

	log_debug("bus_addr  = %p\n", channels[channel].mbox.bus_addr);
	log_debug("virt_addr = %p\n", channels[channel].mbox.virt_addr);

#if 0
	//
	// der folgende Code wird in servod nicht eingesetzt.
	//
	if (0) {
		channels[channel].page_map = malloc(channels[channel].num_pages * sizeof(*channels[channel].page_map));

		if (channels[channel].page_map == 0)
		return fatal("rpio-pwm: Failed to malloc page_map: %m\n");

		memfd = open("/dev/mem", O_RDWR);
		if (memfd < 0)
		return fatal("rpio-pwm: Failed to open /dev/mem: %m\n");
		pid = getpid();
		sprintf(pagemap_fn, "/proc/%d/pagemap", pid);
		fd = open(pagemap_fn, O_RDONLY);
		if (fd < 0)
		return fatal("rpio-pwm: Failed to open %s: %m\n", pagemap_fn);

		if (lseek(fd, (uint32_t) channels[channel].virtbase >> 9, SEEK_SET) != (uint32_t) channels[channel].virtbase >> 9) {
			return fatal("rpio-pwm: Failed to seek on %s: %m\n", pagemap_fn);
		}
		for (i = 0; i < channels[channel].num_pages; i++) {
			uint64_t pfn;
			channels[channel].page_map[i].virtaddr = channels[channel].virtbase + i * PAGE_SIZE;
			// Following line forces page to be allocated
			channels[channel].page_map[i].virtaddr[0] = 0;
			if (read(fd, &pfn, sizeof(pfn)) != sizeof(pfn))
			return fatal("rpio-pwm: Failed to read %s: %m\n", pagemap_fn);
			if (((pfn >> 55) & 0x1bf) != 0x10c)
			return fatal("rpio-pwm: Page %d not present (pfn 0x%016llx)\n", i, pfn);
			channels[channel].page_map[i].physaddr = (uint32_t) pfn << PAGE_SHIFT | 0x40000000;
		}
		close(fd);
		close(memfd);
	}
#endif
	return EXIT_SUCCESS;
}

static int init_virtbase(int channel) {
#if 0
	channels[channel].virtbase = mmap(NULL, channels[channel].num_pages * PAGE_SIZE, PROT_READ | PROT_WRITE,
			MAP_SHARED | MAP_ANONYMOUS | MAP_NORESERVE | MAP_LOCKED, -1, 0);

	if (channels[channel].virtbase == MAP_FAILED)
	return fatal("rpio-pwm: Failed to mmap physical pages: %m\n");
	if ((unsigned long) channels[channel].virtbase & (PAGE_SIZE - 1))
	return fatal("rpio-pwm: Virtual address is not page aligned\n");
#endif
	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
//
// Initialize control block for this channel
//
static int init_ctrl_data(int channel) {
	log_debug("10 init_ctrl_data()\n");

	dma_cb_t *cbp = (dma_cb_t *) get_cb(channel);
	uint32_t *sample = (uint32_t *) get_dp(channel);

	uint32_t phys_gpclr0 = periph_phys_base + GPIO_BASE_OFFSET + 0x28;

	channels[channel].dma_reg = map_peripheral(DMA_VIRT_BASE, DMA_LEN) + (DMA_CHANNEL_INC * channel);
	if (channels[channel].dma_reg == NULL) {
		printf("channels[channel].dma_reg == NULL\n");
		return EXIT_FAILURE;
	}
	log_debug("20 init_ctrl_data()\n");
	uint32_t phys_fifo_addr, cbinfo;
	if (delay_hw == DELAY_VIA_PWM) {
		phys_fifo_addr = PWM_PHYS_BASE + 0x18;
		cbinfo = DMA_NO_WIDE_BURSTS | DMA_WAIT_RESP | DMA_D_DREQ | DMA_PER_MAP(5);
	} else {
		phys_fifo_addr = PCM_PHYS_BASE + 0x04;
		cbinfo = DMA_NO_WIDE_BURSTS | DMA_WAIT_RESP | DMA_D_DREQ | DMA_PER_MAP(2);
	}

	// Reset complete per-sample gpio mask to 0
	memset(sample, 0, sizeof(channels[channel].num_samples * sizeof(uint32_t)));
	log_debug("30 init_ctrl_data()\n");

	// For each sample we add 2 control blocks:
	// - first: clear gpio and jump to second
	// - second: jump to next CB

	for (int i = 0; i < channels[channel].num_samples; i++) {

		// log_debug("35 init_ctrl_data() %4d\n", i);

		cbp->info = DMA_NO_WIDE_BURSTS | DMA_WAIT_RESP;
		cbp->src = mem_virt_to_phys(channel, sample + i); // src contains mask of which gpios need change at this sample
		cbp->dst = phys_gpclr0; // set each sample to clear set gpios by default
		cbp->length = 4;
		cbp->stride = 0;
		cbp->next = mem_virt_to_phys(channel, cbp + 1);
		cbp++;

		// Delay
		cbp->info = cbinfo;
		cbp->src = mem_virt_to_phys(channel, sample); // Any data will do
		cbp->dst = phys_fifo_addr;
		cbp->length = 4;
		cbp->stride = 0;
		cbp->next = mem_virt_to_phys(channel, cbp + 1);
		cbp++;
	}
	log_debug("40 init_ctrl_data()\n");
	// The last control block links back to the first (= endless loop)
	cbp--;
	cbp->next = mem_virt_to_phys(channel, get_cb(channel));

	// Initialize the DMA channel 0 (p46, 47)
	channels[channel].dma_reg[DMA_CS] = DMA_RESET; // DMA channel reset
	udelay(10);
	channels[channel].dma_reg[DMA_CS] = DMA_INT | DMA_END; // Interrupt status & DMA end flag
	channels[channel].dma_reg[DMA_CONBLK_AD] = mem_virt_to_phys(channel, get_cb(channel));  // initial CB
	channels[channel].dma_reg[DMA_DEBUG] = 7; // clear debug error flags
	channels[channel].dma_reg[DMA_CS] = 0x10880001; // go, mid priority, wait for outstanding writes
	log_debug("50 init_ctrl_data()\n");
	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
// Initialize PWM or PCM hardware once for all channels (10MHz)
static void init_hardware(void) {
	log_debug("init_hardware()\n");

	if (delay_hw == DELAY_VIA_PWM) {

		/* (taken from pigpio):  kill the clock if busy, anything else isn't reliable */
#if 1
		while (clk_reg[PWMCLK_CNTL] & CLK_CNTL_BUSY) {
			clk_reg[PWMCLK_CNTL] = BCM_PASSWD | CLK_CNTL_KILL;
		}
#endif
		// Initialise PWM
		//
		// Source=PLLD (500MHz)
		// 0x5A000000 is the  BCM-password
		//
		clk_reg[PWMCLK_CNTL] = BCM_PASSWD | CLK_CNTL_SRC_PLLD;         // Source=PLLD (500MHz)
		udelay(10);
		clk_reg[PWMCLK_DIV] = BCM_PASSWD | (50 << 12); // set pwm div to 50, giving 10MHz
		udelay(10);
		clk_reg[PWMCLK_CNTL] |= BCM_PASSWD | CLK_CNTL_ENAB;        // Source=PLLD and enable
		udelay(10);

		pwm_reg[PWM_CTL] = 0;
		udelay(10);
		pwm_reg[PWM_STA] = -1;
		udelay(10);

		pwm_reg[PWM_RNG1] = pulse_width_incr_us * 10;
		udelay(10);
		{
//		  pwmReg[PWM_DMAC] = PWM_DMAC_ENAB      |
//		                      PWM_DMAC_PANIC(15) |
//		                      PWM_DMAC_DREQ(15);

			pwm_reg[PWM_DMAC] = PWMDMAC_ENAB | PWMDMAC_THRSHLD;
			udelay(10);
		}
		pwm_reg[PWM_CTL] = PWMCTL_CLRF;
		udelay(10);
		pwm_reg[PWM_CTL] = PWMCTL_USEF1 | PWMCTL_MODE1 | PWMCTL_PWEN1;
		udelay(10);

	} else {

		/* (taken from pigpio):  kill the clock if busy, anything else isn't reliable */
#if 1
		while (clk_reg[PCMCLK_CNTL] & CLK_CNTL_BUSY) {
			clk_reg[PCMCLK_CNTL] = BCM_PASSWD | CLK_CNTL_KILL;
		}
#endif
		// Initialise PCM
		clk_reg[PCMCLK_CNTL] = BCM_PASSWD | CLK_CNTL_SRC_PLLD;         // Source=PLLD (500MHz)
		udelay(10);
		clk_reg[PCMCLK_DIV] = BCM_PASSWD | (50 << 12); // Set pcm div to 50, giving 10MHz
		udelay(10);
		clk_reg[PCMCLK_CNTL] |= BCM_PASSWD | CLK_CNTL_ENAB;        // Source=PLLD and enable
		udelay(10);

		pcm_reg[PCM_CS_A] = 1;                // Disable Rx+Tx, Enable PCM block
		udelay(10);
		pcm_reg[PCM_TXC_A] = 0 << 31 | 1 << 30 | 0 << 20 | 0 << 16; // 1 channel, 8 bits
		udelay(10);
		pcm_reg[PCM_MODE_A] = (pulse_width_incr_us * 10 - 1) << 10;
		udelay(10);
		pcm_reg[PCM_CS_A] |= 1 << 4 | 1 << 3;        // Clear FIFOs
		udelay(10);
		pcm_reg[PCM_DREQ_A] = 64 << 24 | 64 << 8; // DMA Req when one slot is free?
		udelay(10);
		pcm_reg[PCM_CS_A] |= 1 << 9;            // Enable DMA
		udelay(10);
		pcm_reg[PCM_CS_A] |= 1 << 2;            // Enable Tx
	}
}

// --------------------------------------------------------------------------------------
// Setup a channel with a specific subcycle time. After that pulse-widths can be
// added at any time.
int init_channel(int channel, int subcycle_time_us) {

	log_debug("Initializing channel %d...\n", channel);

	if (_is_setup == 0)
		return fatal("Error: you need to call `setup(..)` before initializing channels\n");

	if (channel > DMA_CHANNELS - 1)
		return fatal("Error: maximum channel is %d (requested channel %d)\n",
		DMA_CHANNELS - 1, channel);

	if (is_channel_initialized(channel))
		return fatal("Error: channel %d already initialized.\n", channel);

	if (subcycle_time_us < SUBCYCLE_TIME_US_MIN)
		return fatal("Error: subcycle time %dus is too small (min=%dus)\n", subcycle_time_us, SUBCYCLE_TIME_US_MIN);

	// Setup Data
	channels[channel].subcycle_time_us = subcycle_time_us;
	channels[channel].num_samples = channels[channel].subcycle_time_us / pulse_width_incr_us;
	channels[channel].width_max = channels[channel].num_samples - 1;
	channels[channel].num_cbs = channels[channel].num_samples * 2;
	channels[channel].num_pages = ((channels[channel].num_cbs * 32 + channels[channel].num_samples * 4 +
	PAGE_SIZE - 1) >> PAGE_SHIFT);

	// Initialize channel
	if (init_virtbase(channel) == EXIT_FAILURE)
		return EXIT_FAILURE;

	if (make_pagemap(channel) == EXIT_FAILURE)
		return EXIT_FAILURE;

	if (init_ctrl_data(channel) == EXIT_FAILURE) {
		return EXIT_FAILURE;

	} else {
		//printf("kein EXIT_FAILURE\n");
	}

	set_channel_initialized(channel, 1);
	return EXIT_SUCCESS;
}

// --------------------------------------------------------------------------------------
// Print some info about a channel
int print_channel(int channel) {

	if (channel > DMA_CHANNELS - 1)
		return fatal("Error: you tried to print channel %d, but max channel is %d\n", channel, DMA_CHANNELS - 1);
	log_debug("Subcycle time: %dus\n", channels[channel].subcycle_time_us);
	log_debug("PW Increments: %dus\n", pulse_width_incr_us);
	log_debug("Num samples:   %d\n", channels[channel].num_samples);
	log_debug("Num CBS:       %d\n", channels[channel].num_cbs);
	log_debug("Num pages:     %d\n", channels[channel].num_pages);
	return EXIT_SUCCESS;
}

void set_softfatal(int enabled) {
	soft_fatal = enabled;
}

char *
get_error_message(void) {
	return error_message;
}

// --------------------------------------------------------------------------------------
//
// get board hardware descriptor
// no attempt is made to check for pinout descriptors
//
static int get_board_model(void) {
	char buf[256], modelstr[256];
	modelstr[0] = '\0';

	FILE *fp;
	fp = fopen("/proc/cpuinfo", "r");
	if (!fp)
		fatal("Unable to open /proc/cpuinfo: %m\n");

	char *res;
	while ((res = fgets(buf, 256, fp))) {
		if (!strncasecmp("hardware", buf, 8))
			memcpy(modelstr, buf, 256);
	}
	fclose(fp);

	int board_model = -1;

	if (modelstr[0] == '\0')
		fatal("servod: No 'Hardware' record in /proc/cpuinfo\n");

	if (strstr(modelstr, "BCM2708"))
		board_model = 1;
	else if (strstr(modelstr, "BCM2709"))
		board_model = 2;
	else {
		//
		// from this line you see where this code is 'borrowed'
		//
		fatal("servod: Cannot parse the hardware name string\n");
	}
	return board_model;
}

// --------------------------------------------------------------------------------------
//
void setBaseAddresses(int board_model) {
	log_debug("setBaseAddresses(%d)\n", board_model);

	if (board_model == 1) {
		// BCM2708_PI1_PERI_BASE
		periph_virt_base = 0x20000000;
		periph_phys_base = 0x7e000000;
		dram_phys_base = 0x40000000;
		mem_flag = 0x0c;
	} else {
		// BCM2709_PI2_PERI_BASE
		periph_virt_base = 0x3f000000;
		periph_phys_base = 0x7e000000;
		dram_phys_base = 0xc0000000;
		mem_flag = 0x04;
	}
}

// --------------------------------------------------------------------------------------
// setup(..) needs to be called once and starts the PWM timer. delay hardware
// and pulse-width-increment-granularity is set for all DMA channels and cannot
// be changed during runtime due to hardware mechanics (specific PWM timing).

int setup(int pw_incr_us, int hw) {
	log_debug("setup()\n");

	board_model = get_board_model();
	setBaseAddresses(board_model);

	delay_hw = hw;
	pulse_width_incr_us = pw_incr_us;

	if (_is_setup == 1)
		return fatal("Error: setup(..) has already been called before\n");

	log_debug("Using hardware: %s\n", delay_hw == DELAY_VIA_PWM ? "PWM" : "PCM");
	log_debug("PW increments:  %dus\n", pulse_width_incr_us);

	// Catch all kind of kill signals
	setup_sighandlers();

	// Initialize common stuff

	pwm_reg = map_peripheral(PWM_VIRT_BASE, PWM_LEN);
	pcm_reg = map_peripheral(PCM_VIRT_BASE, PCM_LEN);
	clk_reg = map_peripheral(CLK_VIRT_BASE, CLK_LEN);
	gpio_reg = map_peripheral(GPIO_VIRT_BASE, GPIO_LEN);

	if (pwm_reg == NULL || pcm_reg == NULL || clk_reg == NULL || gpio_reg == NULL)
		return EXIT_FAILURE;

	// Start PWM/PCM timing activity
	init_hardware();

	_is_setup = 1;
	return EXIT_SUCCESS;
}

int is_setup(void) {
	return _is_setup;
}

int is_channel_initialized(int channel) {
	return channels[channel].initialized;
}
void set_channel_initialized(int channel, int value) {
	channels[channel].initialized = value;
}

int get_pulse_incr_us(void) {
	return pulse_width_incr_us;
}

int get_channel_subcycle_time_us(int channel) {
	return channels[channel].subcycle_time_us;
}

// --------------------------------------------------------------------------------------
//
int main(int argc, char **argv) {
	printf("---- main start\n");
	set_loglevel(LOG_LEVEL_DEBUG);

	// Very crude...
	if (argc == 2 && !strcmp(argv[1], "--pcm"))
		setup(PULSE_WIDTH_INCREMENT_GRANULARITY_US_DEFAULT, DELAY_VIA_PCM);
	else
		setup(PULSE_WIDTH_INCREMENT_GRANULARITY_US_DEFAULT, DELAY_VIA_PWM);

	// Setup demo parameters
	int demo_timeout = 10 * 1000 * 1000;
	int demo_blink = 200 * 1000;
	int gpio = 17;
	int channel = 6;
	int subcycle_time_us = SUBCYCLE_TIME_US_DEFAULT; // 20ms;

	{
		//Blink code
		int i = 0;
		for (i = 0; i < 4; i++) {
			init_gpio(gpio);
			usleep(demo_blink);
			init_gpio_high(gpio);
			usleep(demo_blink);
		}
		init_gpio(gpio);
	}

	// Setup channel
	init_channel(channel, subcycle_time_us);
	print_channel(channel);

	add_channel_pulse(channel, gpio, 0, 100);
	printf("timeout %d\n", demo_timeout);
	usleep(demo_timeout);
	usleep(demo_timeout);

	// Use the channel for various pulse widths
	add_channel_pulse(channel, gpio, 0, 41);
	add_channel_pulse(channel, gpio, 60, 31);
	printf("timeout %d\n", demo_timeout);
	usleep(demo_timeout);

	add_channel_pulse(channel, gpio, 110, 21);
	add_channel_pulse(channel, gpio, 150, 11);
	add_channel_pulse(channel, gpio, 180, 1);
	printf("pulses added\n");

	printf("timeout %d\n", demo_timeout);
	usleep(demo_timeout);

	// Clear and start again
	clear_channel_gpio(channel, gpio);
	add_channel_pulse(channel, gpio, 0, 300);

	printf("timeout %d\n", demo_timeout);
	usleep(demo_timeout);

	// All done
	shutdown();
	printf("---- main end\n");
	exit(0);
}
