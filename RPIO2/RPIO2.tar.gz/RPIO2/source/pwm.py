import RPIO2.PWM
import time

RPIO2.PWM.set_loglevel( RPIO2.PWM.LOG_LEVEL_DEBUG )

channel = 6
frequency = 50
port = 17

RPIO2.PWM.init_channel( channel, int(1000000 / frequency) )

value = 10

nd = 1000000/frequency / 10
ndx = int( nd * value )    

RPIO2.PWM.set_pwm ( channel, port, ndx )

time.sleep(30)

RPIO2.PWM.clear_channel_gpio ( channel, port )
RPIO2.PWM.clear_channel( channel )

