"""
Demonstration of how to control servo pulses with RPIO.PWM
RPIO Documentation: http://pythonhosted.org/RPIO
"""
import RPIO2.PWM as PWM
import time
GPIO = 17
GPIO2=27
CHANNEL = 14

PWM.set_loglevel(PWM.LOG_LEVEL_ERRORS)

PWM.setup()
PWM.init_channel(CHANNEL)

PWM.set_loglevel(PWM.LOG_LEVEL_DEBUG)
PWM.print_channel(CHANNEL)
PWM.set_loglevel(PWM.LOG_LEVEL_ERRORS)

td = 0.09
tb = 0.04

if False:
    print('1, 1999')
    for _ in range(4):
        PWM.set_pwm (CHANNEL, GPIO, 1)
        time.sleep(tb)
        PWM.set_pwm (CHANNEL, GPIO, 1999)
        time.sleep(tb)
        
    print('0, 2000')
    for _ in range(4):
        PWM.set_pwm (CHANNEL, GPIO, 0)
        time.sleep(tb)
        PWM.set_pwm (CHANNEL, GPIO, 2000)
        time.sleep(tb)

while True:
    # making pulses shorter costs some internal delay  
    for tx in range(1920, 0, -40):
        PWM.set_pwm (CHANNEL, GPIO, tx)
        PWM.set_pwm (CHANNEL, GPIO2, 2000-tx)
        
        time.sleep(tb)
        
    # making pulses longer can be done without internal delay 
    for tx in range(10, 2000, +40):
        PWM.set_pwm (CHANNEL, GPIO, tx)
        PWM.set_pwm (CHANNEL, GPIO2, 2000-tx)
        time.sleep(tb)
    
