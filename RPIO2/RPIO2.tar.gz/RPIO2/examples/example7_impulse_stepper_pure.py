"""
Demonstration of how to control servo pulses with RPIO.PWM
RPIO Documentation: http://pythonhosted.org/RPIO
"""
import RPIO.PWM as PWM
import time
br0_0 = 25
br0_1 = 24
br1_0 = 23
br1_1 = 18


# PWM.set_loglevel(PWM.LOG_LEVEL_DEBUG)

import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)

GPIO.setup(br0_0, GPIO.OUT)
GPIO.setup(br0_1, GPIO.OUT)
GPIO.setup(br1_0, GPIO.OUT)
GPIO.setup(br1_1, GPIO.OUT)

increment = 10
delay = 200

for _ in range(0,4000):
    GPIO.output(br0_0, GPIO.HIGH)
    GPIO.output(br0_1, GPIO.HIGH)
    GPIO.output(br1_0, GPIO.LOW)
    GPIO.output(br1_1, GPIO.LOW)
    time.sleep(0.002)
    
    GPIO.output(br0_0, GPIO.LOW)
    GPIO.output(br0_1, GPIO.HIGH)
    GPIO.output(br1_0, GPIO.HIGH)
    GPIO.output(br1_1, GPIO.LOW)
    time.sleep(0.002)
    
    GPIO.output(br0_0, GPIO.LOW)
    GPIO.output(br0_1, GPIO.LOW)
    GPIO.output(br1_0, GPIO.HIGH)
    GPIO.output(br1_1, GPIO.HIGH)
    time.sleep(0.002)
    
    GPIO.output(br0_0, GPIO.HIGH)
    GPIO.output(br0_1, GPIO.LOW)
    GPIO.output(br1_0, GPIO.LOW)
    GPIO.output(br1_1, GPIO.HIGH)
    time.sleep(0.002)
    

