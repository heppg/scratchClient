#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Demonstration of how to control servo pulses with RPIO.PWM
RPIO Documentation: http://pythonhosted.org/RPIO
"""
from RPIO2 import PWM
import time

servo = PWM.Servo(dma_channel=6)

# Add servo pulse for GPIO 17 with 1200�s (1.2ms)
servo.set_servo(17, 1200)
time.sleep(10)

# Add servo pulse for GPIO 17 with 2000�s (2.0ms)
servo.set_servo(17, 2000)
time.sleep(10)

# Clear servo on GPIO17
servo.stop_servo(17)
