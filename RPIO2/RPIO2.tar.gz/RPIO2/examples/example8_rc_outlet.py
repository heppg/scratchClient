"""
Demonstration of how to control rc controlled outlets
"""
import RPIO2.PWM as PWM
import time
GPIO_17 = 17
CHANNEL = 14

PWM.set_loglevel(PWM.LOG_LEVEL_DEBUG)
cbs_per_bit = 2

PWM.setup(pulse_incr_us= (350 / cbs_per_bit) )
bits = (12*8 + 32 ) * 4 * cbs_per_bit + cbs_per_bit * 20

print("--- bits", bits)

PWM.init_channel(CHANNEL, subcycle_time_us=350 * bits / cbs_per_bit)

PWM.set_loglevel(PWM.LOG_LEVEL_DEBUG)
PWM.print_channel(CHANNEL)


on  = "11111" + "10000" + "10" + "x"
off = "11111" + "10000" + "01" + "x"

def send_data(data):
    print(data)
    PWM.clear_channel(CHANNEL)
    indx = 0
    for _ in range(4):
        for c in data:
            print (indx, c)
            if c == '0':
                 
                PWM.add_channel_pulse( CHANNEL, GPIO_17, indx+0*cbs_per_bit, 1*cbs_per_bit)
                PWM.add_channel_pulse( CHANNEL, GPIO_17, indx+4*cbs_per_bit, 3*cbs_per_bit)
                indx += 8 *cbs_per_bit   
            
            if c == '1':
                 
                PWM.add_channel_pulse( CHANNEL, GPIO_17, indx+0*cbs_per_bit, 1*cbs_per_bit)
                PWM.add_channel_pulse( CHANNEL, GPIO_17, indx+4*cbs_per_bit, 1*cbs_per_bit)
                indx += 8*cbs_per_bit
                    
            if c == 'x':
                PWM.add_channel_pulse( CHANNEL, GPIO_17, indx+0*cbs_per_bit, 1*cbs_per_bit)
                indx += 32*cbs_per_bit

print("start")        
try:
    while True:
        send_data(on)
        time.sleep(10)
        send_data(off)
        time.sleep(10)
            
except Exception as e:
    print(e)
    PWM.cleanup()
    