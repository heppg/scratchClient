"""
Demonstration of how to control rc controlled outlets
"""
import RPIO2.PWM as PWM
import time
data = 17
CHANNEL = 14

PWM.set_loglevel(PWM.LOG_LEVEL_ERRORS)

PWM.setup(pulse_incr_us=350)

bits = (12*4 + 32 ) * 4
PWM.init_channel(CHANNEL, subcycle_time_us=350 * bits)

PWM.set_loglevel(PWM.LOG_LEVEL_DEBUG)
PWM.print_channel(CHANNEL)
PWM.set_loglevel(PWM.LOG_LEVEL_ERRORS)


on = "11111" + "10000" + "10"
off = "11111" + "10000" + "01"

def send_data(data):
    print(data)
    PWM.clear_channel()
    indx = 0
    for _ in range(4):
        for c in data:
            if c == '0':
                 
                PWM.add_channel_pulse( CHANNEL, data, indx, 1)
                PWM.add_channel_pulse( CHANNEL, data, indx+4, 3)
                indx += 8    
            if c == '1':
                 
                PWM.add_channel_pulse( CHANNEL, data, indx, 1)
                PWM.add_channel_pulse( CHANNEL, data, indx+4, 1)
                indx += 8
                    
            if c == 'x':
                PWM.add_channel_pulse( CHANNEL, data, indx, 1)
                indx += 32
        
try:
    while true:
        send_data(on)
        time.sleep(10)
        send_data(off)
        time.sleep(10)
            
except Exception:
    PWM.cleanup()
    