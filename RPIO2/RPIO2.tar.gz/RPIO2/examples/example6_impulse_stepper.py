"""
Demonstration of how to control servo pulses with RPIO.PWM
RPIO Documentation: http://pythonhosted.org/RPIO
"""
import RPIO.PWM as PWM
import time
br0_0 = 25
br0_1 = 24
br1_0 = 23
br1_1 = 18

CHANNEL = 14

# PWM.set_loglevel(PWM.LOG_LEVEL_DEBUG)

PWM.setup()

increment = 10
delay = 200

PWM.init_channel(CHANNEL, 4 * increment * delay)
PWM.print_channel(CHANNEL)
#               [ 1, 1,   0, 0],
#               [ 0, 1,   1, 0],
#               [ 0, 0,   1, 1],
#               [ 1, 0,   0, 1],

PWM.add_channel_pulse(CHANNEL, br0_0,   0,     1* delay-1)
PWM.add_channel_pulse(CHANNEL, br0_0, 3*delay, 1* delay-1)

PWM.add_channel_pulse(CHANNEL, br0_1,   0,     2*delay-1)

PWM.add_channel_pulse(CHANNEL, br1_0, 1*delay, 2*delay-1)

PWM.add_channel_pulse(CHANNEL, br1_1, 2*delay, 2*delay-1)

time.sleep(60)





